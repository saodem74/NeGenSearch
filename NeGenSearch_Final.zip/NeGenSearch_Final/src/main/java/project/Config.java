package project;

/**
 * @author Harry Tran on 9/8/19.
 * @project SE6362
 * @email trunghieu.tran@utdallas.edu
 * @organization UTDallas
 */
public class Config {
	public static final String IndexedFile =  "/Users/tranhieu/Desktop/NeGenSearch_2/src/main/resources/indexed/SortedIndex.txt";
	public static final String IdToURL =  "/Users/tranhieu/Desktop/NeGenSearch_2/src/main/resources/indexed/IdToURL.txt";
	public static final String IdToContent =  "/Users/tranhieu/Desktop/NeGenSearch_2/src/main/resources/indexed/IdToContent.txt";
}
