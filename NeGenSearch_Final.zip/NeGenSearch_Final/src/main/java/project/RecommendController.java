package project;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;


@WebServlet("/RecommendController")
public class RecommendController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    /*
     * 1. get query String from view
     * 2. run bash to generate ResultSearch.txt
     * 3. read line one by one
     * */

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
System.out.println("aaaaa");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String inputStr = request.getParameter("term");
        System.out.println("InputString: " + inputStr);

        // TODO - This is for recommendation
//        String q = "a";
        List<String> list = bashRunController.getRecommendationQuery(inputStr);
        JSONArray results = new JSONArray(list);

        PrintWriter out = response.getWriter();
        out.print(results.toString());
        out.flush();

    }

}
