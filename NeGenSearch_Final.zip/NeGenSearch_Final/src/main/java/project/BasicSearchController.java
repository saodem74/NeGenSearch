package project;

import project.utils.FileReader;

import java.util.*;

/**
 * @author Harry Tran on 10/21/19.
 * @project Crawler
 * @email trunghieu.tran@utdallas.edu
 * @organization UTDallas
 */
public class BasicSearchController {
	static private Map<Integer, String> mapIDtoURL = new HashMap<>();
	static private Map<String, Integer> mapURLtoID = new HashMap<>();
	static private Map<Integer, List<String>> mapIDtoContent = new HashMap<>();
	static private List<int[]> indexes = null;
	static private BasicSearchController instance;
	static private Set<Integer> removedID = new HashSet<>();

	public static BasicSearchController getInstance() {
		if (instance == null) {
			instance = new BasicSearchController();
		}
		return instance;
	}


	private BasicSearchController() {
		init();
	}

	private void init() {
		indexes = new ArrayList<int[]>();
		removedID.add(-1);

		String data = FileReader.readStringFromFile(Config.IndexedFile);
		String[] lines = data.split("\n");
		for (String line : lines) {
			String[] ss = line.split(" ");
			int id = Integer.parseInt(ss[0]);
			int shift = Integer.parseInt(ss[1]);
			int[] tmp = {id, shift};
			indexes.add(tmp);
		}

		data = FileReader.readStringFromFile(Config.IdToURL);
		lines = data.split("\n");
		for (String line : lines) {
			String[] ss = line.split(" ");
			mapIDtoURL.put(Integer.parseInt(ss[0]), ss[1]);
			mapURLtoID.put(ss[1], Integer.parseInt(ss[0]));
		}

		data = FileReader.readStringFromFile(Config.IdToContent);
		lines = data.split("\n");
		for (String line : lines) {
			String[] ss = line.split(" ");
			List<String> content = new ArrayList<String>();
			for (int i = 1; i < ss.length; ++i)
				content.add(ss[i]);
			mapIDtoContent.put(Integer.parseInt(ss[0]), content);
		}
	}

	public String getContentFromIndexies(int id, int shift) {
		List<String> str = mapIDtoContent.getOrDefault(id, null);
		if (str == null) return null;
		StringBuilder sb = new StringBuilder();
		for (int i = shift; i < str.size(); ++i)
			sb.append(str.get(i)).append(" ");
		for (int i = 0; i < shift; ++i)
			sb.append(str.get(i)).append(" ");
		return sb.toString();
	}

	public String getContentFromIndexiesForRecommendation(int id, int shift) {
		List<String> str = mapIDtoContent.getOrDefault(id, null);
		if (str == null) return null;
		StringBuilder sb = new StringBuilder();
		int cc = 0;
		for (int i = shift; i < str.size(); ++i) {
			if (cc >= 2) break;
			sb.append(str.get(i)).append(" ");
			++cc;
		}
		for (int i = 0; i < shift; ++i) {
			if (cc >= 2) break;
			sb.append(str.get(i)).append(" ");
			++cc;
		}
		return sb.toString();
	}

	public List<String> analyzeQuery(String query) {
		List<String> res = new ArrayList<>();
		// NOT
		if (query.indexOf("not ") == 0) {
			res.add("not");
			String tmp = query.substring(4);
			res.add(tmp);
		} else// AND
		if (query.contains(" and ")) {
			res.add("and");
			int i = query.indexOf(" and ");
			res.add(query.substring(0, i));
			res.add(query.substring(i + 5));
		} else // OR
		if (query.contains(" or ")) {
			res.add("or");
			int i = query.indexOf(" or ");
			res.add(query.substring(0, i));
			res.add(query.substring(i + 4));
		} else {
			res.add("-");
			res.add(query);
		}
		return res;
	}

	public List<String[]> searchNotSingleQuery(String query) {
		if (indexes == null) init();
		List<String[]> res = new ArrayList<>();

		Set<Integer> inq = new HashSet<>();

		int l = 0, r = indexes.size() - 1;
		int pos = -1;
		while (l <= r) {
			int mid = (l + r) / 2;
			String tmpStr = getContentFromIndexies(indexes.get(mid)[0], indexes.get(mid)[1]);
			if (tmpStr.startsWith(query)) {
				pos = mid;
				r = mid - 1;
			}
			if (tmpStr.compareTo(query) < 0) l = mid + 1;
			else r = mid - 1;
		}
		if (pos != -1) {
			l = pos;
			r = indexes.size() - 1;
			int pos2 = pos;
			while (l <= r) {
				int mid = (l + r) / 2;
				String tmpStr = getContentFromIndexies(indexes.get(mid)[0], indexes.get(mid)[1]);
				if (tmpStr.startsWith(query)) {
					pos2 = mid;
					l = mid + 1;
				}
				if (tmpStr.compareTo(query) < 0) l = mid + 1;
				else r = mid - 1;
			}
			// from pos -> pos2
			for (int i = 0; i < pos; ++i) {
				if (!inq.contains(indexes.get(i)[0])) {
					String[] tmpi = {mapIDtoURL.get(indexes.get(i)[0]), getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1])};
					inq.add(indexes.get(i)[0]);
					res.add(tmpi);
				}
			}
			for (int i = pos2 + 1; i < indexes.size(); ++i) {
				if (!inq.contains(indexes.get(i)[0])) {
					String[] tmpi = {mapIDtoURL.get(indexes.get(i)[0]), getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1])};
					inq.add(indexes.get(i)[0]);
					res.add(tmpi);
				}
			}


		} else {
			for (int i = 0; i < indexes.size(); ++i) {
				if (!inq.contains(indexes.get(i)[0])) {
					String[] tmpi = {mapIDtoURL.get(indexes.get(i)[0]), getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1])};
					inq.add(indexes.get(i)[0]);
					res.add(tmpi);
				}
			}
		}

		return res;
	}

	public List<String[]> searchSingleQuery(String query) {
		if (indexes == null) init();
		List<String[]> res = new ArrayList<>();
		Set<Integer> inq = new HashSet<>();

		int l = 0, r = indexes.size() - 1;
		int pos = -1;
		while (l <= r) {
			int mid = (l + r) / 2;
			String tmpStr = getContentFromIndexies(indexes.get(mid)[0], indexes.get(mid)[1]);
			if (tmpStr.startsWith(query)) {
				pos = mid;
				break;
			}
			if (tmpStr.compareTo(query) < 0) l = mid + 1;
			else r = mid - 1;
		}

		if (pos != -1) {
			String[] tmp = {mapIDtoURL.get(indexes.get(pos)[0]), getContentFromIndexies(indexes.get(pos)[0], indexes.get(pos)[1])};
			inq.add(indexes.get(pos)[0]);
			res.add(tmp);
			int i = pos - 1;
			while (i >= 0) {
				String tmpStr = getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1]);
				if (tmpStr.startsWith(query)) {
					if (!inq.contains(indexes.get(i)[0])) {
						String[] tmpi = {mapIDtoURL.get(indexes.get(i)[0]), getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1])};
						inq.add(indexes.get(i)[0]);
						res.add(tmpi);
					}
					--i;
				} else break;
			}

			i = pos + 1;
			while (i < indexes.size()) {
				String tmpStr = getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1]);
				if (tmpStr.startsWith(query)) {
					if (!inq.contains(indexes.get(i)[0])) {
						String[] tmpi = {mapIDtoURL.get(indexes.get(i)[0]), getContentFromIndexies(indexes.get(i)[0], indexes.get(i)[1])};
						inq.add(indexes.get(i)[0]);
						res.add(tmpi);
					}
					++i;
				} else break;
			}
		}
		return res;
	}

	public List<String[]> searchAndQuery(List<String> queries) {
		if (indexes == null) init();
		List<String[]> res = new ArrayList<>();
		Set<String> inq = new HashSet<>();
		List<String[]> res1 = searchSingleQuery(queries.get(0));
		List<String[]> res2 = searchSingleQuery(queries.get(1));
		for (String[] ss : res1) {
			inq.add(ss[0]);
		}
		Set<String> inq2 = new HashSet<>();
		for (String[] ss : res2) {
			if (inq.contains(ss[0])) {
				if (!inq2.contains(ss[0])) {
					inq2.add(ss[0]);
					res.add(ss);
				}
			}
		}
		return res;
	}

	public List<String[]> searchOrQuery(List<String> queries) {
		if (indexes == null) init();
		List<String[]> res = new ArrayList<>();
		Set<String> inq = new HashSet<>();
		List<String[]> res1 = searchSingleQuery(queries.get(0));
		List<String[]> res2 = searchSingleQuery(queries.get(1));
		for (String[] ss : res1) {
			if (!inq.contains(ss[0])) {
				inq.add(ss[0]);
				res.add(ss);
			}
		}
		for (String[] ss : res2) {
			if (!inq.contains(ss[0])) {
				inq.add(ss[0]);
				res.add(ss);
			}
		}
		return res;
	}

	public List<String> getRecommendation(String query) {

		Map<String, Integer> count = new HashMap<>();

		int l = 0, r = indexes.size() - 1;
		int pos = -1;
		while (l <= r) {
			int mid = (l + r) / 2;
			String tmpStr = getContentFromIndexiesForRecommendation(indexes.get(mid)[0], indexes.get(mid)[1]);
			if (tmpStr.startsWith(query)) {
				pos = mid;
				break;
			}
			if (tmpStr.compareTo(query) < 0) l = mid + 1;
			else r = mid - 1;
		}

		if (pos != -1) {
			String tmp = getContentFromIndexiesForRecommendation(indexes.get(pos)[0], indexes.get(pos)[1]);
			count.put(tmp, count.getOrDefault(tmp, 0) + 1);
			int i = pos - 1;
			while (i >= 0) {
				String tmpStr = getContentFromIndexiesForRecommendation(indexes.get(i)[0], indexes.get(i)[1]);
				if (tmpStr.startsWith(query)) {
					count.put(tmpStr, count.getOrDefault(tmpStr, 0) + 1);
					--i;
				} else break;
			}

			i = pos + 1;
			while (i < indexes.size()) {
				String tmpStr = getContentFromIndexiesForRecommendation(indexes.get(i)[0], indexes.get(i)[1]);
				if (tmpStr.startsWith(query)) {
					count.put(tmpStr, count.getOrDefault(tmpStr, 0) + 1);
					++i;
				} else break;
			}
		}

		List<String> res = new ArrayList<>();
		for (String key : count.keySet()) {
			res.add(key);
		}
		for (int i = 0; i < res.size(); ++i)
			for (int j = i + 1; j < res.size(); ++j) {
				if (count.get(res.get(i)) < count.get(res.get(j))) {
					String tmp = res.get(i);
					res.set(i, res.get(j));
					res.set(j, tmp);
				}
			}

		List<String> res2 = new ArrayList<>();
		for (int i = 0; i < Math.min(10, res.size()); ++i)
			res2.add(res.get(i));
		return res2;
	}

	public List<String[]> getResultQuery(String query) {
		if (indexes == null) init();
		List<String[]> result;

		List<String> qr = analyzeQuery(query);
		System.out.println("Operator = " + qr.get(0));
		for (int i = 1; i < qr.size(); ++i)
			System.out.println("Query " + i + " = " + qr.get(i));

		if (qr.get(0).equals("not")) {
			result =  searchNotSingleQuery(qr.get(1));
		}
		else
		if (qr.get(0).equals("and")) {
			List<String> queries = new ArrayList<>();
			queries.add(qr.get(1));
			queries.add(qr.get(2));
			result =  searchAndQuery(queries);
		}
		else
		if (qr.get(0).equals("or")) {
			List<String> queries = new ArrayList<>();
			queries.add(qr.get(1));
			queries.add(qr.get(2));
			result =  searchOrQuery(queries);
		}
		else
			result = searchSingleQuery(qr.get(1));

		//
		List<String[]> result2 = new ArrayList<>();

		for (int i = 0; i < Math.min(100, result.size()); ++i) {
			if (removedID.contains(mapURLtoID.getOrDefault(result.get(i)[0], -1))) continue;
			int ii = Math.min(100, result.get(i)[1].length());
			String[] tmp = {result.get(i)[0], "..." + result.get(i)[1].substring(0, ii) + "...\n"};
			result2.add(tmp);

		}

		return result2;
	}

	public void deleteURL(String url) {
		removedID.add(mapURLtoID.getOrDefault(url, -1));
	}

	public void main(String[] args) {
		String query = "video and audio";

		System.out.println("Get query = >>" + query + "<<");

		List<String[]> res = BasicSearchController.getInstance().getResultQuery(query);

	}
}
